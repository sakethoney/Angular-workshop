import { InjectionToken } from '@angular/core'

export let JQ_TOKEN = new InjectionToken<Object>('jQuery');
